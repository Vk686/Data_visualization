from django.contrib import admin
from enroll.models import User
# Register your models here.

admin.site.register(User)