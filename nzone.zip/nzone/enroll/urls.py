from django.contrib import admin
from django.urls import path
from .import views


urlpatterns = [
    path('', views.login_view, name="login"),
    path('delete/<int:id>/', views.user_delete, name="delete"),
    path('edit/<int:id>/', views.user_edit, name="edit"),

]
