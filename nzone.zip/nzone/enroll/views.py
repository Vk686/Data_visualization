from django.shortcuts import render, redirect
from .forms import UserForm
from .models import User

# Create your views here.
def login_view(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            password = form.cleaned_data['password']
            reg = User(name=name, email=email, phone=phone, password=password)

            reg.save()
            form = UserForm(request.POST)

    else:
        form = UserForm() 
    user = User.objects.all()     
          
    return render(request, "enroll/login.html", {'form':form, 'user':user})

def user_edit(request, id):
    if request.method == 'POST':
        user = User.objects.get(pk=id)
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
    else:
        user = User.objects.get(pk=id)
        form = UserForm(instance=user)

    return render(request, "enroll/signup.html", {'form':form})    

def user_delete(request, id):
    if request.method == 'POST':

        user = User.objects.get(pk=id)
        user.delete()
        return redirect('/')

